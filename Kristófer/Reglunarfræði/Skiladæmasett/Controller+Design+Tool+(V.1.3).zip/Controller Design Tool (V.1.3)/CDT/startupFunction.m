function startupFunction()
% Initialize all global variables as one
addpath global
setGlobal_c(1,1);
setGlobal_f(1);
setGlobal_g(1,1);
setGlobal_h(1,1);