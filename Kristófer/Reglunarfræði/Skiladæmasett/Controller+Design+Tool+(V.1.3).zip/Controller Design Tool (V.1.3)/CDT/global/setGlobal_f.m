function setGlobal_f(val)
global f;
f = val;
