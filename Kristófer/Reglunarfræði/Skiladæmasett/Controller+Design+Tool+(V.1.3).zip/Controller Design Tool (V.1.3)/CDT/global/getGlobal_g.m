function [num, den] = getGlobal_g()
global gNum gDen;
num = gNum; den = gDen;
