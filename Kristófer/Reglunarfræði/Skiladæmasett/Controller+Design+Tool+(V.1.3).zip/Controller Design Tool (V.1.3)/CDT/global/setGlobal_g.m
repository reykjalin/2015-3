function setGlobal_g(num, den)
global gNum gDen;
gNum = num; gDen = den;