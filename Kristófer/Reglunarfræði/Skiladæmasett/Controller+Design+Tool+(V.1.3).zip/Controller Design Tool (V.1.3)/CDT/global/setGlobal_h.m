function setGlobal_h(num, den)
global hNum hDen;
hNum = num; hDen = den;
