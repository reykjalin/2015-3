function [num, den] = getGlobal_c()
global cNum cDen;
num = cNum; den = cDen;
