function [num, den] = getGlobal_h()
global hNum hDen;
num = hNum; den = hDen;