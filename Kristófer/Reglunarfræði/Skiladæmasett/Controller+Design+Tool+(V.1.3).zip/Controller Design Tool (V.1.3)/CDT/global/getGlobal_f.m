function out = getGlobal_f()
global f;
out = f;