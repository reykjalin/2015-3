function resetGlobals()
% Set gloabal variables to unity
setGlobal_f(1);
setGlobal_c(1, 1);
setGlobal_g(1, 1);
setGlobal_h(1, 1);
