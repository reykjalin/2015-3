function setGlobal_c(num, den)
global cNum cDen;
cNum = num; cDen = den;