function startupFunction()
% Initialize all global variables as one
addpath global
resetGlobals();
