function [k, num, den] = getGlobal_g()
global gNum gDen gK;
num = gNum; den = gDen; k = gK;
