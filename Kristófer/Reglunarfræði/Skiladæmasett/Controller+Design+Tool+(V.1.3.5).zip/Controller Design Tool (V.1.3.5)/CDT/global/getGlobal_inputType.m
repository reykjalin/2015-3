function [out] = getGlobal_inputType()

global inputType;
out = inputType;