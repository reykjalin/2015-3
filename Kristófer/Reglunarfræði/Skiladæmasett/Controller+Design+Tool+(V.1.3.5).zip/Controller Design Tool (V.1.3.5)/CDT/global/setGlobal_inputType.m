function setGlobal_inputType(val)

global inputType;
inputType = val;