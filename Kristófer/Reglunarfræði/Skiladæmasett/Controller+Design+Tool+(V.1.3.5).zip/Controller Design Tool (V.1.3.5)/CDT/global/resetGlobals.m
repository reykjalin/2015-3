function resetGlobals()
% Set gloabal variables to unity
setGlobal_f(1,1,1);
setGlobal_c(1,1,1);
setGlobal_g(1,1,1);
setGlobal_h(1,1,1);

setGlobalStrings('1', '', '', 'F(s)');
setGlobalStrings('1', '', '', 'G(s)');
setGlobalStrings('1', '', '', 'C(s)');
setGlobalStrings('1', '', '', 'H(s)');
