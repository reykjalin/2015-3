function setGlobal_c(k, num, den)
global cNum cDen cK;
cNum = num; cDen = den; cK = k;