function [k, num, den] = getGlobal_c()
global cK cNum cDen;
num = cNum; den = cDen; k = cK;
