function [k, num, den] = getGlobal_f()
global fNum fDen fK;
num = fNum; den = fDen; k = fK;