function [k, num, den] = getGlobal_h()
global hNum hDen hK;
num = hNum; den = hDen; k = hK;