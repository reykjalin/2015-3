function setGlobal_h(k, num, den)
global hK hNum hDen;
hNum = num; hDen = den; hK = k;
