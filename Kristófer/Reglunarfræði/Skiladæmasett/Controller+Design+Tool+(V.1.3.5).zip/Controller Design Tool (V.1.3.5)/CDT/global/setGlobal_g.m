function setGlobal_g(k, num, den)
global gK gNum gDen;
gNum = num; gDen = den; gK = k;