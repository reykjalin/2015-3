function setGlobal_f(k, num, den)
global fK fNum fDen; 
fNum = num; fDen = den; fK = k;
